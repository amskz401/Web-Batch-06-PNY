const express = require("express");
const {
  userRegister,
  userLogin,
} = require("../server/controller/userController");

const router = express.Router();

// Users Routes
router.get("/login", (req, res) => {
  res.render("login");
});

router.get("/register", (req, res) => {
  res.render("register");
});

router.post("/register", userRegister);

router.post("/login", userLogin);

module.exports = router;
