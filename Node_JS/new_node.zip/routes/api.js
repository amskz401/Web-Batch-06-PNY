const express = require("express");

const router = express.Router();

router.get("/get-list", (req, res) => {
  const data = [
    { id: 1, name: "Farhan" },
    { id: 2, name: "Ahmad" },
    { id: 3, name: "Ali" },
  ];
  res.send(data);
});

// router.post("/", (req, res) => {

// });

// router.put();

// router.delete();

// router.all();

module.exports = router;
