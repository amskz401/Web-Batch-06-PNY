const User = require("../model/User");
const bcrypt = require("bcrypt");
// const saltRounds = 10;
// const myPlaintextPassword = "s0//P4$$w0rD";
// const someOtherPlaintextPassword = "not_bacon";

const userRegister = (req, res) => {
  bcrypt.hash(req.body.user_password, 10, function (err, hash) {
    const user_data = {
      user_email: req.body.user_email,
      user_password: hash,
    };
    const new_user = new User(user_data);
    new_user
      .save()
      .then((data) => {
        console.log(data);
        res.redirect("/login");
      })
      .catch((error) => {
        console.log(`Query Error: ${error}`);
      });
  });
};

const userLogin = (req, res) => {
  User.findOne({ user_email: req.body.user_email })
    .then((user) => {
      if (user) {
        bcrypt
          .compare(req.body.user_password, user.user_password)
          .then(function (result) {
            if (result) {
              res.send("<h1>Login Successfull</h1>");
            } else {
              res.send("<h1>Login Failed</h1>");
            }
          })
          .catch((error) => {
            console.log(`Error Bcrypt`);
          });
      } else {
        res.redirect("/login");
      }
    })
    .catch((error) => {
      console.log(`Query Error`);
    });
};

module.exports = { userRegister, userLogin };
