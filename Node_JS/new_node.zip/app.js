const express = require("express");
require("dotenv").config();
require("./server/config/db");
const cors = require("cors");
const app = express();
// if (process.env.PORT) {
//   PORT = process.env.PORT;
// } else {
//   PORT = 4000;
// }
const PORT = process.env.PORT || 4000;

// Default Engine
app.set("view engine", "ejs");

//
app.use(cors());

//
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Welcome");
});

//
app.use("/", require("./routes/web"));

//
app.use("/api", require("./routes/api"));

app.listen(PORT, () => {
  console.log(`Server at ${PORT}`);
});
