const express = require("express");
const { createServer } = require("node:http");
const { Server } = require("socket.io");

const app = express();
const server = createServer(app);
const io = new Server(server);

app.use(express.static("public"));
const PORT = 3000;

app.get("/", (req, res) => {
  res.send("hello");
});

io.on("connection", (socket) => {
  socket.broadcast.emit("joined_user", "new user joined the chat");

  socket.on("chat_message", (msg) => {
    io.emit("deliver_message", msg);
  });
  //   console.log("a user connected");
  //   socket.on("disconnect", () => {
  //     console.log("user disconnected");
  //   });
});

server.listen(PORT, () => {
  console.log(`Started at: ${PORT}`);
});
